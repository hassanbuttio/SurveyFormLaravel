<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Persons;
class MainController extends Controller
{
   function index()
   {
   	return view('index');
   }

   function insertSurvey(Request $request)
   {
   		$Persons	=	Persons::create(

   			[
   				'fullname' => $request->fullname,
   			   	'email' => $request->email,
   			   	'gender' => $request->gender,
   			   	'city' => $request->city,
   			   	'profession' => $request->profession,
   			   	'age' => $request->age,
   			   	'column1' => $request->column1,
   			   	'column2' => $request->column2,
   			   	'column3' => $request->column3

   			]
   		);

   		if($Persons)
   		{
   			return redirect('/')->with('message',"Form Submitted Successfully");
   		}
   		else{
   			return redirect('/')->with('message',"Form Not Submitted");

   		}
   }

   function viewSurvey(){
      $Persons =  Persons::all();
      return view('view',['Persons' => $Persons]);
   }

      function singleSurvey(Persons $persons){
      $Persons =  Persons::find($persons);
      return view('edit',['Persons' => $Persons]);
   }
     function updateSurvey(Request $request){
      $Persons =  Persons::find($request->id);

      $Persons->fullname = $request->fullname;

      $updated = $Persons->save();
   if($updated)
         {
            return redirect('/success')->with('message',"Form Updated Successfully");
         }
         else{
            return redirect('/success')->with('message',"Form Not Updated");

         }

   }
}
