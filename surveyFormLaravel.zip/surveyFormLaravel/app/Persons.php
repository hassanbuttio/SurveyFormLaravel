<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Persons extends Model
{
    protected $fillable	=	['fullname','email','age','gender','city','profession','column1','column2','column3'];
}
