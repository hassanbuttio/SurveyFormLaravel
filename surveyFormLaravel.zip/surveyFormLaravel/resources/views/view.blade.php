<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
  <br />
  <h4>All Survey Users</h4>
  <hr>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Fullname</th>
        <th>Age</th>
        <th>Gender</th>
        <th>City</th>
        <th>Email</th>
        <th>Action</th>

      </tr>
    </thead>
    <tbody>
      @foreach($Persons as $Person)
      <tr>
        <td>{{ $Person->fullname}}</td>
        <td>{{ $Person->age}}</td>
        <td>{{ $Person->gender}}</td>
        <td>{{ $Person->city}}</td>
        <td>{{ $Person->email}}</td>
        <td><a href="{{URL('edit').'/'.$Person->id}}">Edit</a></td>

      </tr>
          

      @endforeach

    </tbody>
  </table>
</div>

</body>
</html>
