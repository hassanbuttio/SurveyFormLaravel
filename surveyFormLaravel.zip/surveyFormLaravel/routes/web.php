<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/','MainController@index');
Route::post('/submitted','MainController@insertSurvey');
Route::get('/view','MainController@viewSurvey');
Route::get('/edit/{persons}','MainController@singleSurvey');
Route::post('/updated','MainController@updateSurvey');
Route::get('/success',function(){
	return view('success');
});
