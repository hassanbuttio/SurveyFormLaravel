<!DOCTYPE html>
<html lang="en">
<head>
  <title>Ramadan Survey Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<style>
.form-control{
  border-radius:0px;
  border:none;

}
label{
  color:white;
  margin-top:2%;
}
body{
  background-image:url("  public/back_1.jpg");
  background-repeat:no-repeat;
  background-size:100vw 100vh;
}

  </style>


<body>
<br /><br />

<div class="container">
  <h4>Quick Survey Form</h4>
  <hr>
  <?php if(session('message')): ?>

<h4 class="alert alert-danger"><?php echo e(session('message')); ?></h4> 

  <?php endif; ?>
      <form action="<?php echo e(URL('/submitted')); ?>" method="POST">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="row"> 
    <div class="col-sm-6" style="background-color:#022040;">
       <div class="form-group">
        <label for="fullname">Fullname:</label>
        <input type="text" required class="form-control" id="fullname" name="fullname">
      </div>

     <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" required class="form-control" id="email" name="email">
      </div>

              <label for="fullname">Gender:</label>

      <div class="form-check-inline">

  <label class="form-check-label">
    <input type="radio" class="form-check-input" value="M" name="gender">Male
  </label>
</div>
<div class="form-check-inline">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="F"  name="gender">Female
  </label>
</div>
   <div class="form-group">
    <br />

        <label for="city">City:</label>
<select required class="form-control" id="city" name="city">
    <option value="khi">Karachi</option>
    <option value="lhr">Lahore</option>
  </select>   
     </div>

        <div class="form-group">
    <br />

        <label for="city">Profession:</label>
<select required class="form-control" id="profession" name="profession">
    <option value="stud">Student</option>
        <option value="prof">Professional</option>

  </select>   
     </div>

             <div class="form-group">
    <br />

        <label for="city">Age:</label>
<select required class="form-control" id="profession" name="age">
        <option value="b18">Below 18</option>
        <option value="b1820">Above 18 Or 20 Below</option>
        <option value="b2025">Above 20 Or 25 Below</option>
        <option value="b2530">Above 25 Or 30 Below</option>
        <option value="b3040">Above 30 Or 40 Below</option>
        <option value="b4050">Above 40 Or 50 Below</option>

  </select>   
     </div>
    </div>


    <div class="col-sm-6" style="background-color:#0c63c1;">
         <b> <label for="">1)- Which drink you prefer in ramadan?:</label></b>

      <div class="form-check">

  <label class="form-check-label">
    <input type="radio" class="form-check-input" value="1"  name="column1">Rooh Afza
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="2" name="column1">Tang
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="3"  name="column1">Cold Drink
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="4"  name="column1">Lassi
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="5"  name="column1">Jaam-e-Shireen
  </label>
</div>


       <b> <label for="fullname">2)- Which fried item you prefer the most in ramadan?:</label></b>

      <div class="form-check">

  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="1" name="column2">Pakora
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="2"  name="column2">Samosa
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="3"  name="column2">Spring Roll
  </label>
</div>

       <b><label for="">3)- What you prefer in sehri?</label></b>

      <div class="form-check">

  <label class="form-check-label">
    <input type="radio" class="form-check-input" value="1"  name="column3">Paratha Anda
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="2"  name="column3">Paratha Chai
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="3"  name="column3">Salan Roti
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="4"  name="column3">Paratha Salan
  </label>
</div>
<div class="form-check">
  <label class="form-check-label">
    <input type="radio" class="form-check-input"  value="5"  name="column3">Khajla Pheyoni
  </label>
</div>

 

    </div>
   <input type="submit" name="submit" style="background-color:#061d35;color:white;border-radius:0px;" class="btn btn-block" value="Submit Form">
  </div>

  <br />


    </form>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\surveyFormLaravel\resources\views/index.blade.php ENDPATH**/ ?>