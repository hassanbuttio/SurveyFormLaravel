<!DOCTYPE html>
<html lang="en">
<head>
  <title>Edit User</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
  <br />
  <h4>Edit User</h4>
  <hr>
  <?php $__currentLoopData = $Persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(URL('/updated')); ?>" method="POST">
  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">  

<label>ID:</label>
<input type="text" name="id" value="<?php echo e($Person->id); ?>">
<label>FullName:</label>
<input type="text" name="fullname" value="<?php echo e($Person->fullname); ?>">

<input type="submit" name="submit" value="Update" class="btn btn-primary">  
</form>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\surveyFormLaravel\resources\views/edit.blade.php ENDPATH**/ ?>