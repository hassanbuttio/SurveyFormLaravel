<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
  <br />
  <h4>All Survey Users</h4>
  <hr>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Fullname</th>
        <th>Age</th>
        <th>Gender</th>
        <th>City</th>
        <th>Email</th>
        <th>Action</th>

      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $Persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($Person->fullname); ?></td>
        <td><?php echo e($Person->age); ?></td>
        <td><?php echo e($Person->gender); ?></td>
        <td><?php echo e($Person->city); ?></td>
        <td><?php echo e($Person->email); ?></td>
        <td><a href="<?php echo e(URL('edit').'/'.$Person->id); ?>">Edit</a></td>

      </tr>
          

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\surveyFormLaravel\resources\views/view.blade.php ENDPATH**/ ?>